import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import fs from "fs/promises";
import path from "path";
import { exec } from "child_process";
import util from "util";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

const execAsync = util.promisify(exec);

export interface PluginInfo {
    name: string;
    description: string;
    url: string;
}

export class PluginManager {
    public clients: Map<string, Client> = new Map();
    public pluginTools: Map<string, any[]> = new Map(); // ClientID -> Tool[]
    private pluginsDir: string;

    constructor() {
        this.pluginsDir = path.join(process.cwd(), "plugins");
    }

    async init() {
        await fs.mkdir(this.pluginsDir, { recursive: true });
        await this.loadInstalledPlugins();
    }

    async fetchAwesomeSkills(): Promise<PluginInfo[]> {
        const res = await fetch("https://awesome-skills.com/");
        const html = await res.text();
        const jsonLdMatches = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g);
        let skills: PluginInfo[] = [];

        if (jsonLdMatches) {
            for (const match of jsonLdMatches) {
                const jsonStr = match.replace(/<script type="application\/ld\+json">|<\/script>/g, "").trim();
                try {
                    const data = JSON.parse(jsonStr);
                    if (data["@type"] === "ItemList" && data.itemListElement) {
                        for (const item of data.itemListElement) {
                            if (item.item) {
                                skills.push({
                                    name: item.item.name,
                                    description: item.item.description,
                                    url: item.item.url
                                });
                            }
                        }
                    }
                } catch (e) {
                    console.error("Error parsing JSON-LD", e);
                }
            }
        }
        return skills;
    }

    async installPlugin(githubUrl: string, name: string): Promise<string> {
        const safeName = name.replace(/[^a-zA-Z0-9_-]/g, "_");
        const targetDir = path.join(this.pluginsDir, safeName);
        
        try {
            const stat = await fs.stat(targetDir);
            if (stat.isDirectory()) {
                return `Plugin ${name} is already installed at ${targetDir}`;
            }
        } catch (e) {
            // Does not exist, proceed
        }

        try {
            await execAsync(`git clone ${githubUrl} ${targetDir}`);
            // Attempt to install dependencies if package.json exists
            try {
                await fs.stat(path.join(targetDir, "package.json"));
                await execAsync(`npm install`, { cwd: targetDir });
                // Attempt build if there's a build script
                const pkgJson = JSON.parse(await fs.readFile(path.join(targetDir, "package.json"), "utf-8"));
                if (pkgJson.scripts && pkgJson.scripts.build) {
                    await execAsync(`npm run build`, { cwd: targetDir });
                }
            } catch (e) {
                // Ignore if no package.json
            }
            
            // Attempt to load it
            await this.loadPlugin(targetDir, safeName);
            return `Successfully installed and loaded plugin: ${name}`;
        } catch (e: any) {
            throw new Error(`Failed to install plugin ${name}: ${e.message}`);
        }
    }

    async loadInstalledPlugins() {
        try {
            const files = await fs.readdir(this.pluginsDir, { withFileTypes: true });
            for (const file of files) {
                if (file.isDirectory()) {
                    await this.loadPlugin(path.join(this.pluginsDir, file.name), file.name).catch(e => {
                        console.error(`Failed to load plugin ${file.name}:`, e);
                    });
                }
            }
        } catch (e) {
            console.error("Error loading installed plugins", e);
        }
    }

    private async loadPlugin(pluginDir: string, id: string) {
        // Simple heuristic: if there's a package.json, run `npm start` or find main
        // Better: just use npx or node directly if we know the entry
        // For now, let's look for package.json
        let command = "node";
        let args: string[] = [];

        try {
            const pkgPath = path.join(pluginDir, "package.json");
            const pkgStr = await fs.readFile(pkgPath, "utf-8");
            const pkg = JSON.parse(pkgStr);
            
            if (pkg.bin) {
                const binPath = typeof pkg.bin === "string" ? pkg.bin : Object.values(pkg.bin)[0];
                args = [path.join(pluginDir, binPath as string)];
            } else if (pkg.main) {
                args = [path.join(pluginDir, pkg.main)];
            } else {
                throw new Error("No main or bin found in package.json");
            }
        } catch (e) {
            // Fallback to npx using the directory if package.json failed
            command = "npx";
            args = ["-y", "."];
        }

        const transport = new StdioClientTransport({
            command,
            args,
            stderr: "inherit"
        });

        const client = new Client({
            name: "cerberus-aggregator",
            version: "1.0.0"
        }, {
            capabilities: {}
        });

        await client.connect(transport);
        this.clients.set(id, client);

        const toolsResult = await client.request({ method: "tools/list" }, ListToolsRequestSchema) as any;
        if (toolsResult && toolsResult.tools) {
            this.pluginTools.set(id, toolsResult.tools);
        }
    }

    async proxyListTools(): Promise<any[]> {
        let allTools: any[] = [];
        for (const [id, tools] of this.pluginTools.entries()) {
            allTools = allTools.concat(tools);
        }
        return allTools;
    }

    async proxyCallTool(name: string, args: any): Promise<any> {
        // Find which client owns this tool
        for (const [id, tools] of this.pluginTools.entries()) {
            if (tools.find(t => t.name === name)) {
                const client = this.clients.get(id);
                if (client) {
                    return await client.request(
                        { method: "tools/call", params: { name, arguments: args } },
                        CallToolRequestSchema
                    );
                }
            }
        }
        throw new Error(`Tool ${name} not found in any loaded plugins.`);
    }
}

export const pluginManager = new PluginManager();
